sap.ui.define([
		"sapui5/demo/odata/list/controller/BaseController",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"
	], function (BaseController) {
	"use strict";

	return BaseController.extend("sapui5.demo.odata.list.controller.Master", {

	});
});